//
//  BannerService.swift
//  MSA
//
//  بيجيب البانرات من الباك اند وبيكاشها في UserDefaults
//  بنفس أسلوب BankRateService / OunceService الموجودين في المشروع.
//

import Foundation

final class BannerService {

    private init() { }

    private let bannersKey = "_MSA_|_Home_Banners_"

    // MARK: - Cache

    fileprivate func getUserData() -> [Banner]? {

        let defaults = UserDefaults.standard

        guard let saved = defaults.object(forKey: bannersKey) as? Data,
              let loaded = try? JSONDecoder().decode([Banner].self, from: saved)
        else { return nil }

        return loaded
    }

    fileprivate func setUserData(_ newValue: [Banner]?) {

        // على عكس BankRateService، هنا مش بنعمل fatalError لو الترميز فشل.
        // البانر حاجة تجميلية — مايستاهلش نكراش التطبيق عشانها.
        guard let encoded = try? JSONEncoder().encode(newValue) else { return }

        UserDefaults.standard.set(encoded, forKey: bannersKey)
    }

    /// آخر بانرات اتحفظت. بتتعرض فوراً وقت فتح الشاشة قبل ما الريكوست يرجّع،
    /// عشان المستخدم ما يشوفش مكان فاضي بيلمع.
    static var userData: [Banner]? {
        get { BannerService().getUserData() }
        set { BannerService().setUserData(newValue) }
    }

    // MARK: - Fetch

    /// بيجيب البانرات المفعّلة من الباك اند.
    /// - Parameter completion: بترجع على الـ main thread.
    static func fetchBanners(completion: @escaping ([Banner]) -> Void) {

        let url = "\(hostName)\(EndPoints.banners.rawValue)"

        APIClient.shared.performRequestWithAlamofire(
            urlString: url,
            method: .get,
            parameters: nil
        ) { (model: BannersResponse?, error: String?) in

            if let error {
                print("BannerService error ----> \(error)")
            }

            guard let rawItems = model?.data else {
                return
            }

            let items = rawItems

            BannerService.userData = items

            DispatchQueue.main.async {
                completion(items)
            }
        }
    }
}
