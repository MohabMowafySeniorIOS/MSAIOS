//
//  BannerModel.swift
//  MSA
//
//  موديل بانرات الرئيسية.
//
//  ملحوظة مهمة: الـ structs دي (Title / Description / Status / Label)
//  معرّفة أصلاً في NewsModel.swift ومستخدمة في أكتر من مكان، فمش بنعيد
//  تعريفها هنا عشان ما يحصلش "Invalid redeclaration". بنستخدمها زي ما هي.
//

import Foundation

// MARK: - Banners Response

struct BannersResponse: Codable {
    let meta: Meta
    let data: [Banner]
    let links: PaginationLinks
}

// MARK: - Banner

struct Banner: Codable {
    let id: Int
    let name: String
    let mediaType: MediaType
    let mediaURL: String
    let thumbURL: String?
    let order: Int
    let startsAt: String?
    let endsAt: String?
    let createdAt: String
    let updatedAt: String
    let link: BannerLink
    let status: BannerStatus

    enum CodingKeys: String, CodingKey {
        case id
        case name
        case mediaType = "media_type"
        case mediaURL = "media_url"
        case thumbURL = "thumb_url"
        case order
        case startsAt = "starts_at"
        case endsAt = "ends_at"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
        case link
        case status
    }
}

// MARK: - Media Type

enum MediaType: String, Codable {
    case image
    case video
}

// MARK: - Banner Link

struct BannerLink: Codable {
    let type: String
    let url: String?
}

// MARK: - Banner Status

struct BannerStatus: Codable {
    let label: StatusLabel
    let value: String
}

// MARK: - Status Label

struct StatusLabel: Codable {
    let ar: String
    let en: String
}


// MARK: - Meta Link

struct MetaLink: Codable {
    let active: Bool
    let label: String
    let page: Int?
    let url: String?
}

// MARK: - Pagination Links

struct PaginationLinks: Codable {
    let first: String?
    let last: String?
    let next: String?
    let prev: String?
}
