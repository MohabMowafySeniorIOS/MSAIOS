//
//  HomeVC+Banner.swift
//  MSA
//
//  ربط سلايدر البانر بالـ `banneView` الموجودة أصلاً في Home.storyboard.
//
//  ملحوظة: الـ banneView جوه stackView رأسي وليها constraint ارتفاع 150.
//  يعني لما نخفيها الـ stackView بيقفل مكانها لوحده، والشاشة بتترص عادي
//  من غير فراغ — فمش محتاجين نلعب في الـ constraints.
//

import UIKit
import SwiftUI
import AVKit
import ObjectiveC

private var bannerSliderKey: UInt8 = 0

extension HomeVC {

    // MARK: - إعدادات السلوك

    /// لو البانر عنده لينك، اللينك ياخد الأولوية على فتح الميديا؟
    ///
    /// `false` = الضغط بيفتح الصورة بالزووم أو الفيديو بملء الشاشة (السلوك الحالي).
    /// `true`  = لو فيه لينك بيتفتح، ولو مفيش بتتفتح الميديا.
    ///
    /// غيّر السطر ده لو قررت إن البانرات الإعلانية المفروض توديه على صفحة.
    private var linkTakesPriority: Bool { false }

    /// بنستخدم associated object لأن الـ extension مينفعش يضيف stored property.
    /// لو حبيت تنضّفها أكتر، انقل السطر ده جوه كلاس HomeVC نفسه:
    /// `var bannerSlider: BannerSliderView?`
    var bannerSlider: BannerSliderView? {
        get { objc_getAssociatedObject(self, &bannerSliderKey) as? BannerSliderView }
        set { objc_setAssociatedObject(self, &bannerSliderKey, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC) }
    }

    // MARK: - Setup

    /// نادِها من `viewDidLoad` في HomeVC.
    func setupBannerSlider() {

        // نبدأ مخفية. لو مفيش بانرات خالص، الرئيسية تفضل زي ما هي بالظبط.
        banneView.isHidden = true

        let slider = BannerSliderView()
        slider.translatesAutoresizingMaskIntoConstraints = false

        slider.onTapBanner = { [weak self] item in
            self?.handleBannerTap(item)
        }

        banneView.addSubview(slider)

        NSLayoutConstraint.activate([
            slider.topAnchor.constraint(equalTo: banneView.topAnchor),
            slider.leadingAnchor.constraint(equalTo: banneView.leadingAnchor),
            slider.trailingAnchor.constraint(equalTo: banneView.trailingAnchor),
            slider.bottomAnchor.constraint(equalTo: banneView.bottomAnchor)
        ])
        

        self.bannerSlider = slider
        self.bannerSlider?.backgroundColor = .clear
     

        loadBanners()
    }

    // MARK: - Loading

    func loadBanners() {

        BannerService.fetchBanners { [weak self] items in
            self?.apply(banners: items)
        }
    }

    private func apply(banners: [Banner]) {

        bannerSlider?.setItems(banners)
        banneView.isHidden = banners.isEmpty

        if !banners.isEmpty {
            bannerSlider?.viewWillAppear()
        }
    }

    // MARK: - الضغط على البانر

    private func handleBannerTap(_ item: Banner) {

        if linkTakesPriority, let link = URL(string: item.mediaURL) {
            openLink(link)
            return
        }

        switch item.mediaType {

        case .image:
            openImageViewer(item)

        case .video:
            openVideoPlayer(item)
        }
    }

    /// الصورة بتتفتح بملء الشاشة مع زووم إن وآوت.
    ///
    /// بنستخدم `PhotoDetialsVC` الموجودة أصلاً في المشروع
    /// (نفس الشاشة اللي `AllNewsVC` بيستخدمها) بدل ما نعمل واحدة جديدة.
    /// الزووم فيها متظبط من 1x لـ 6x عن طريق UIScrollView.
    private func openImageViewer(_ item: Banner) {

        guard !item.mediaURL.isEmpty else { return }

        // بنوقف السلايدر قبل ما نفتح، عشان ما يفضلش بيقلب
        // ورا الشاشة اللي فوقه ويستهلك داتا على الفاضي.
        bannerSlider?.viewWillDisappear()

        Helper.openZoomAbleImage(image: [item.mediaURL], vc: self, index: 0)
    }

    /// الفيديو بيتفتح بملء الشاشة، بالصوت، وبأزرار التحكم الكاملة
    /// (تشغيل، إيقاف، شريط تقدّم، AirPlay، picture-in-picture).
    private func openVideoPlayer(_ item: Banner) {

      

        bannerSlider?.viewWillDisappear()

        // على عكس البانر، هنا المستخدم طلب الفيديو بنفسه —
        // فالصوت بيشتغل حتى لو مفتاح الصامت مقفول.
        BannerAudioSession.setPlayback()

        guard let url = URL(string: item.mediaURL) else { return }
        let player = AVPlayer(url: url)

        let controller = AVPlayerViewController()
        controller.player = player
        controller.modalPresentationStyle = .fullScreen
        controller.entersFullScreenWhenPlaybackBegins = true
        controller.exitsFullScreenWhenPlaybackEnds = false

        present(controller, animated: true) {
            player.play()
        }
    }

    private func openLink(_ link: URL) {

        let webView = WebView(url: link)
        let hosting = UIHostingController(rootView: webView)

        navigationController?.isNavigationBarHidden = false
        tabBarController?.tabBar.isHidden = true
        navigationController?.pushViewController(hosting, animated: true)
    }

    // MARK: - Lifecycle hooks

    /// نادِها من `viewWillAppear` في HomeVC.
    func resumeBannerSlider() {

        // رجعنا من مشغل الفيديو أو من شاشة الزووم:
        // نرجّع الجلسة الصوتية لوضع "ما تزعجش حد" قبل ما البانر يشتغل تاني.
        BannerAudioSession.setAmbient()

        bannerSlider?.viewWillAppear()
    }

    /// نادِها من `viewWillDisappear` في HomeVC.
    func pauseBannerSlider() {
        bannerSlider?.viewWillDisappear()
    }
}
